export type SessionStatus = "pending" | "completed" | "cancelled"
export type EvolutionStatus = "melhorando" | "estavel" | "declinio"
export type PatientStatus = "ativo" | "pendente" | "concluido"
export type UserRole = "admin" | "user"

export interface Session {
  id: string
  number: number
  date: string
  time: string
  status: SessionStatus
  observation: string
  evolution: EvolutionStatus | null
  therapist: string
  type: string
}

export interface Patient {
  id: string
  name: string
  email: string
  phone: string
  cpf: string
  birthDate: string
  address: string
  city: string
  state: string
  cep: string
  clinicalObservations: string
  totalSessions: number
  completedSessions: number
  sessions: Session[]
  status: PatientStatus
  lastVisit: string
  nextAppointment: string
  createdAt: string
  updatedAt: string
}

export interface HistoryEntry {
  id: string
  type: "sessao" | "avaliacao" | "consulta" | "retorno"
  patientId: string
  patientName: string
  date: string
  time: string
  therapist: string
  description: string
  observations: string
}

export interface User {
  email: string
  password: string
  role: UserRole
  name: string
}
