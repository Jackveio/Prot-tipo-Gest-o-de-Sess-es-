export function IntegralClinicaLogo({ className = "w-48 h-12" }: { className?: string }) {
  return (
    <svg viewBox="0 0 200 50" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Circles Logo Design */}
      <circle cx="12" cy="25" r="8" fill="#9b2847" opacity="0.3" />
      <circle cx="20" cy="15" r="8" fill="#9b2847" />
      <circle cx="20" cy="35" r="8" fill="#9b2847" />
      <circle cx="28" cy="25" r="8" fill="#9b2847" opacity="0.3" />

      {/* Text: Integral */}
      <text x="45" y="32" fontFamily="Arial, sans-serif" fontSize="20" fontWeight="700" fill="#9b2847">
        Integral
      </text>

      {/* Text: Clínica */}
      <text x="125" y="32" fontFamily="Arial, sans-serif" fontSize="20" fontWeight="400" fill="#6b7280">
        Clínica
      </text>
    </svg>
  )
}

export function IntegralClinicaIcon({ className = "w-12 h-12" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="24" r="8" fill="#9b2847" opacity="0.3" />
      <circle cx="20" cy="14" r="8" fill="#9b2847" />
      <circle cx="20" cy="34" r="8" fill="#9b2847" />
      <circle cx="28" cy="24" r="8" fill="#9b2847" opacity="0.3" />
    </svg>
  )
}
