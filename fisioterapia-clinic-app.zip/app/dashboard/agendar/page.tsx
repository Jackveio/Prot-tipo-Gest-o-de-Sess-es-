"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Calendar } from "lucide-react"
import Link from "next/link"
import { storage } from "@/lib/storage"
import type { Patient, Session, EvolutionStatus } from "@/types/patient"
import { useToast } from "@/hooks/use-toast"
import { Input } from "@/components/ui/input"

export default function SchedulePage() {
  const router = useRouter()
  const { toast } = useToast()
  const [patients, setPatients] = useState<Patient[]>([])
  const [selectedPatientId, setSelectedPatientId] = useState("")
  const [date, setDate] = useState("")
  const [observation, setObservation] = useState("")
  const [evolution, setEvolution] = useState<EvolutionStatus | "">("")

  useEffect(() => {
    if (!storage.isAuthenticated()) {
      router.push("/login")
      return
    }
    const allPatients = storage.getPatients()
    const activePatients = allPatients.filter((p) => p.completedSessions < p.totalSessions)
    setPatients(activePatients)
  }, [router])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedPatientId || !date) {
      toast({
        title: "Erro",
        description: "Selecione um paciente e uma data",
        variant: "destructive",
      })
      return
    }

    const patient = storage.getPatient(selectedPatientId)
    if (!patient) return

    if (patient.completedSessions >= patient.totalSessions) {
      toast({
        title: "Limite atingido",
        description: "Este paciente já completou todas as sessões",
        variant: "destructive",
      })
      return
    }

    const newSession: Session = {
      id: Date.now().toString(),
      number: patient.completedSessions + 1,
      date,
      status: "completed",
      observation,
      evolution: evolution || null,
    }

    const updatedSessions = [...patient.sessions, newSession]
    storage.updatePatient(selectedPatientId, {
      sessions: updatedSessions,
      completedSessions: patient.completedSessions + 1,
    })

    toast({
      title: "Sessão agendada com sucesso!",
      description: `Sessão ${newSession.number} para ${patient.name}`,
    })

    router.push("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Calendar className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <CardTitle>Agendar Consulta</CardTitle>
                <CardDescription>Registrar nova sessão de fisioterapia</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="patient">Selecionar Paciente *</Label>
                <Select value={selectedPatientId} onValueChange={setSelectedPatientId}>
                  <SelectTrigger id="patient">
                    <SelectValue placeholder="Escolha um paciente" />
                  </SelectTrigger>
                  <SelectContent>
                    {patients.length === 0 ? (
                      <div className="p-2 text-sm text-muted-foreground">Nenhum paciente disponível</div>
                    ) : (
                      patients.map((patient) => (
                        <SelectItem key={patient.id} value={patient.id}>
                          {patient.name} - {patient.completedSessions}/{patient.totalSessions} sessões
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="date">Data da Sessão *</Label>
                <Input id="date" type="date" required value={date} onChange={(e) => setDate(e.target.value)} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="evolution">Evolução do Paciente</Label>
                <Select value={evolution} onValueChange={(value) => setEvolution(value as EvolutionStatus)}>
                  <SelectTrigger id="evolution">
                    <SelectValue placeholder="Selecione a evolução" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="excellent">Excelente</SelectItem>
                    <SelectItem value="good">Boa</SelectItem>
                    <SelectItem value="regular">Regular</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="observation">Observações</Label>
                <Textarea
                  id="observation"
                  placeholder="Descreva detalhes sobre a sessão, exercícios realizados, progresso observado..."
                  value={observation}
                  onChange={(e) => setObservation(e.target.value)}
                  rows={4}
                />
              </div>

              {selectedPatientId && (
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  {(() => {
                    const patient = patients.find((p) => p.id === selectedPatientId)
                    if (!patient) return null
                    return (
                      <>
                        <p className="text-sm font-medium text-foreground">
                          Esta será a sessão {patient.completedSessions + 1} de {patient.totalSessions}
                        </p>
                        <div className="mt-2 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${((patient.completedSessions + 1) / patient.totalSessions) * 100}%` }}
                          />
                        </div>
                      </>
                    )
                  })()}
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <Button
                  type="submit"
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  disabled={patients.length === 0}
                >
                  Confirmar Agendamento
                </Button>
                <Link href="/dashboard" className="flex-1">
                  <Button type="button" variant="outline" className="w-full bg-transparent">
                    Cancelar
                  </Button>
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
