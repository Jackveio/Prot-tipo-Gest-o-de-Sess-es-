"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, AlertCircle } from "lucide-react"
import Link from "next/link"
import { storage } from "@/lib/storage"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function EditPatientPage() {
  const router = useRouter()
  const params = useParams()
  const { toast } = useToast()
  const [errors, setErrors] = useState<{ field: string; message: string }[]>([])
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    cpf: "",
    birthDate: "",
    address: "",
  })

  useEffect(() => {
    if (!storage.isAuthenticated()) {
      router.push("/login")
      return
    }

    const id = params.id as string
    const patient = storage.getPatient(id)
    if (patient) {
      setFormData({
        name: patient.name,
        email: patient.email,
        phone: patient.phone,
        cpf: patient.cpf,
        birthDate: patient.birthDate,
        address: patient.address,
      })
    } else {
      router.push("/dashboard")
    }
  }, [router, params.id])

  const validateForm = (): boolean => {
    const newErrors: { field: string; message: string }[] = []

    if (formData.name.trim().length < 3) {
      newErrors.push({ field: "name", message: "Nome deve ter pelo menos 3 caracteres" })
    }

    const cpfNumbers = formData.cpf.replace(/\D/g, "")
    if (cpfNumbers.length !== 11) {
      newErrors.push({ field: "cpf", message: "CPF deve conter 11 dígitos" })
    }

    const phoneNumbers = formData.phone.replace(/\D/g, "")
    if (phoneNumbers.length < 10) {
      newErrors.push({ field: "phone", message: "Telefone deve conter pelo menos 10 dígitos" })
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.push({ field: "email", message: "E-mail inválido" })
    }

    setErrors(newErrors)
    return newErrors.length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Dados inválidos",
        description: "Por favor, corrija os erros no formulário",
        variant: "destructive",
      })
      return
    }

    const id = params.id as string

    try {
      storage.updatePatient(id, formData)

      toast({
        title: "Dados atualizados com sucesso!",
        description: "As informações do paciente foram atualizadas",
      })

      router.push(`/dashboard/paciente/${id}`)
    } catch (error) {
      if (error instanceof Error && error.message === "CPF_DUPLICATE") {
        setErrors([{ field: "cpf", message: "Este CPF já está cadastrado para outro paciente" }])
        toast({
          title: "CPF duplicado",
          description: "Já existe outro paciente cadastrado com este CPF",
          variant: "destructive",
        })
      } else {
        toast({
          title: "Erro ao atualizar",
          description: "Ocorreu um erro ao atualizar os dados. Tente novamente.",
          variant: "destructive",
        })
      }
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Link href={`/dashboard/paciente/${params.id}`}>
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        {errors.length > 0 && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Erro no formulário</AlertTitle>
            <AlertDescription>
              <ul className="list-disc list-inside space-y-1 mt-2">
                {errors.map((error, index) => (
                  <li key={index}>{error.message}</li>
                ))}
              </ul>
            </AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Editar Dados do Paciente</CardTitle>
            <CardDescription>Atualize as informações cadastrais</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome Completo *</Label>
                <Input
                  id="name"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Digite o nome completo"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cpf">CPF *</Label>
                  <Input
                    id="cpf"
                    required
                    value={formData.cpf}
                    onChange={(e) => setFormData({ ...formData, cpf: e.target.value })}
                    placeholder="000.000.000-00"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="birthDate">Data de Nascimento *</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    required
                    value={formData.birthDate}
                    onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefone *</Label>
                  <Input
                    id="phone"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="(00) 00000-0000"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">E-mail</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="email@exemplo.com"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Endereço</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Rua, número, bairro, cidade"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700">
                  Salvar Alterações
                </Button>
                <Link href={`/dashboard/paciente/${params.id}`} className="flex-1">
                  <Button type="button" variant="outline" className="w-full bg-transparent">
                    Cancelar
                  </Button>
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
