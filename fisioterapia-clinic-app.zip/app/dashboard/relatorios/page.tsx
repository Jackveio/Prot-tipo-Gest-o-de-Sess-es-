"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Users, TrendingUp, Calendar, CheckCircle } from "lucide-react"
import Link from "next/link"
import { storage } from "@/lib/storage"
import type { Patient } from "@/types/patient"

export default function ReportsPage() {
  const router = useRouter()
  const [patients, setPatients] = useState<Patient[]>([])

  useEffect(() => {
    if (!storage.isAuthenticated()) {
      router.push("/login")
      return
    }
    setPatients(storage.getPatients())
  }, [router])

  const totalPatients = patients.length
  const activePatients = patients.filter((p) => p.completedSessions < p.totalSessions && p.completedSessions > 0).length
  const completedPatients = patients.filter((p) => p.completedSessions >= p.totalSessions).length
  const totalSessions = patients.reduce((acc, p) => acc + p.completedSessions, 0)
  const averageProgress = patients.length > 0 ? Math.round((totalSessions / (patients.length * 20)) * 100) : 0

  const excellentEvolution = patients.reduce(
    (acc, p) => acc + p.sessions.filter((s) => s.evolution === "excellent").length,
    0,
  )
  const goodEvolution = patients.reduce((acc, p) => acc + p.sessions.filter((s) => s.evolution === "good").length, 0)
  const regularEvolution = patients.reduce(
    (acc, p) => acc + p.sessions.filter((s) => s.evolution === "regular").length,
    0,
  )

  const getMonthName = (monthIndex: number) => {
    const months = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
    return months[monthIndex]
  }

  const currentMonth = new Date().getMonth()
  const sessionsThisMonth = patients.reduce((acc, p) => {
    return acc + p.sessions.filter((s) => new Date(s.date).getMonth() === currentMonth).length
  }, 0)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground">Relatórios e Estatísticas</h1>
          <p className="text-muted-foreground mt-2">Análise geral da clínica</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-2 border-blue-100">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Pacientes</CardTitle>
              <Users className="h-5 w-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{totalPatients}</div>
              <p className="text-xs text-muted-foreground mt-1">{activePatients} em tratamento</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-green-100">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Sessões Realizadas</CardTitle>
              <Calendar className="h-5 w-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{totalSessions}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {sessionsThisMonth} em {getMonthName(currentMonth)}
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-100">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Progresso Médio</CardTitle>
              <TrendingUp className="h-5 w-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{averageProgress}%</div>
              <p className="text-xs text-muted-foreground mt-1">Taxa de conclusão geral</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-orange-100">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tratamentos Finalizados</CardTitle>
              <CheckCircle className="h-5 w-5 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{completedPatients}</div>
              <p className="text-xs text-muted-foreground mt-1">Pacientes com 20 sessões</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Evolução dos Pacientes</CardTitle>
              <CardDescription>Distribuição das avaliações de evolução</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-foreground">Excelente</span>
                    <span className="text-sm text-muted-foreground">{excellentEvolution} sessões</span>
                  </div>
                  <div className="bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-green-500 h-3 rounded-full"
                      style={{
                        width: `${totalSessions > 0 ? (excellentEvolution / totalSessions) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-foreground">Boa</span>
                    <span className="text-sm text-muted-foreground">{goodEvolution} sessões</span>
                  </div>
                  <div className="bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-blue-500 h-3 rounded-full"
                      style={{
                        width: `${totalSessions > 0 ? (goodEvolution / totalSessions) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-foreground">Regular</span>
                    <span className="text-sm text-muted-foreground">{regularEvolution} sessões</span>
                  </div>
                  <div className="bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-yellow-500 h-3 rounded-full"
                      style={{
                        width: `${totalSessions > 0 ? (regularEvolution / totalSessions) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Status dos Tratamentos</CardTitle>
              <CardDescription>Visão geral do andamento</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                  <div>
                    <p className="text-sm text-muted-foreground">Em Tratamento</p>
                    <p className="text-2xl font-bold text-blue-600">{activePatients}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold text-blue-600">
                      {totalPatients > 0 ? Math.round((activePatients / totalPatients) * 100) : 0}%
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                  <div>
                    <p className="text-sm text-muted-foreground">Finalizados</p>
                    <p className="text-2xl font-bold text-green-600">{completedPatients}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold text-green-600">
                      {totalPatients > 0 ? Math.round((completedPatients / totalPatients) * 100) : 0}%
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm text-muted-foreground">Aguardando Início</p>
                    <p className="text-2xl font-bold text-gray-600">
                      {patients.filter((p) => p.completedSessions === 0).length}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold text-gray-600">
                      {totalPatients > 0
                        ? Math.round((patients.filter((p) => p.completedSessions === 0).length / totalPatients) * 100)
                        : 0}
                      %
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
