import type { Patient, HistoryEntry, User, UserRole } from "@/types/patient"

const STORAGE_KEY = "clinic_patients"
const AUTH_KEY = "clinic_auth"
const USER_KEY = "clinic_user"
const HISTORY_KEY = "clinic_history"

const DEMO_USERS: User[] = [
  {
    email: "admin@clinica.com",
    password: "admin123",
    role: "admin",
    name: "Administrador",
  },
  {
    email: "usuario@clinica.com",
    password: "user123",
    role: "user",
    name: "Usuário",
  },
]

export const storage = {
  getPatients: (): Patient[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(STORAGE_KEY)
    return data ? JSON.parse(data) : []
  },

  savePatients: (patients: Patient[]) => {
    if (typeof window === "undefined") return
    localStorage.setItem(STORAGE_KEY, JSON.stringify(patients))
  },

  addPatient: (patient: Patient) => {
    const patients = storage.getPatients()

    // Check for duplicate CPF
    const duplicateCPF = patients.find((p) => p.cpf === patient.cpf)
    if (duplicateCPF) {
      throw new Error("CPF_DUPLICATE")
    }

    patients.push(patient)
    storage.savePatients(patients)
  },

  updatePatient: (id: string, updates: Partial<Patient>) => {
    const patients = storage.getPatients()
    const index = patients.findIndex((p) => p.id === id)
    if (index !== -1) {
      // Check for duplicate CPF if CPF is being updated
      if (updates.cpf) {
        const duplicateCPF = patients.find((p) => p.cpf === updates.cpf && p.id !== id)
        if (duplicateCPF) {
          throw new Error("CPF_DUPLICATE")
        }
      }

      patients[index] = { ...patients[index], ...updates, updatedAt: new Date().toISOString() }
      storage.savePatients(patients)
    }
  },

  deletePatient: (id: string) => {
    const patients = storage.getPatients()
    const filtered = patients.filter((p) => p.id !== id)
    storage.savePatients(filtered)
  },

  getPatient: (id: string): Patient | undefined => {
    const patients = storage.getPatients()
    return patients.find((p) => p.id === id)
  },

  getHistory: (): HistoryEntry[] => {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(HISTORY_KEY)
    return data ? JSON.parse(data) : []
  },

  saveHistory: (history: HistoryEntry[]) => {
    if (typeof window === "undefined") return
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history))
  },

  addHistoryEntry: (entry: HistoryEntry) => {
    const history = storage.getHistory()
    history.unshift(entry)
    storage.saveHistory(history)
  },

  isAuthenticated: (): boolean => {
    if (typeof window === "undefined") return false
    return localStorage.getItem(AUTH_KEY) === "true"
  },

  login: (email: string, password: string): boolean => {
    const user = DEMO_USERS.find((u) => u.email === email && u.password === password)
    if (user) {
      localStorage.setItem(AUTH_KEY, "true")
      localStorage.setItem(USER_KEY, JSON.stringify({ email: user.email, role: user.role, name: user.name }))
      return true
    }
    return false
  },

  getCurrentUser: (): { email: string; role: UserRole; name: string } | null => {
    if (typeof window === "undefined") return null
    const userData = localStorage.getItem(USER_KEY)
    return userData ? JSON.parse(userData) : null
  },

  isAdmin: (): boolean => {
    const user = storage.getCurrentUser()
    return user?.role === "admin"
  },

  logout: () => {
    if (typeof window === "undefined") return
    localStorage.removeItem(AUTH_KEY)
    localStorage.removeItem(USER_KEY)
  },
}
